# copydir plugin

This plugin is deprecated. Use the [`copypath` plugin](https://github.com/ohmyzsh/ohmyzsh/tree/master/plugins/copypath) instead.
